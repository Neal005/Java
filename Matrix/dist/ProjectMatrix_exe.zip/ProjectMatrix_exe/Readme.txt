Ứng dụng chỉ mở file Matrix (.mt)
